# ReServe

A modern, production-ready React web application for a food surplus redistribution platform. Built with React (Vite), Tailwind CSS 4.0, Firebase, and Google Maps.

## Features
- **Responsive Design**: Mobile-first approach using Tailwind CSS.
- **Authentication**: Firebase Email/Password & Google Sign-In with protected routing (`AuthGuard` & `GuestGuard`).
- **Interactive Maps**: Google Maps integration for locating available harvests and tracking live activity.
- **Custom Design System**: Tailwind v4 configuration with bespoke tokens (colors, typography, spacing).
- **Lazy Loading**: Code splitting via React Router and React Suspense for optimized performance.

## Prerequisites
- Node.js 18+ and npm
- A Firebase Project
- A Google Maps API Key

## Installation

1. **Clone the repository and install dependencies:**
   ```bash
   npm install
   ```

2. **Environment Variables Configuration:**
   Copy `.env.example` to a new file named `.env` and fill in your actual API keys:
   ```bash
   cp .env.example .env
   ```

   Your `.env` should look like this:
   ```env
   VITE_FIREBASE_API_KEY=your_api_key
   VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
   VITE_FIREBASE_PROJECT_ID=your_project_id
   VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
   VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
   VITE_FIREBASE_APP_ID=your_app_id
   VITE_GOOGLE_MAPS_API_KEY=your_google_maps_key
   ```

## Development

To start the local development server:
```bash
npm run dev
```
Navigate to `http://localhost:5173` in your browser.

## Production Build

To build the project for production:
```bash
npm run build
```
This will generate optimized static assets in the `dist` folder.

## Setup Guides

### Firebase Setup
1. Go to the [Firebase Console](https://console.firebase.google.com/) and create a new project.
2. Enable Authentication (Email/Password and Google Provider).
3. Create a Firestore Database.
4. Register a new Web App in your project settings to get your configuration keys.

### Google Maps API Key
1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Enable the **Maps JavaScript API**.
3. Generate an API Key under Credentials and restrict it to your domains for security.
