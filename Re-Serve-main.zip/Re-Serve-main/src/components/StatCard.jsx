import React from 'react';
import Card from './Card';

const StatCard = ({ title, value, unit, subtext, icon, highlight = false, className = '' }) => {
  if (highlight) {
    return (
      <Card className={`bg-reserve-green text-white p-6 flex flex-col justify-center items-center text-center ${className}`}>
        <h3 className="text-sm font-medium tracking-wider mb-2 opacity-90">{title}</h3>
        <div className="text-4xl md:text-5xl font-serif mb-2">{value}</div>
        {subtext && <p className="text-sm opacity-80">{subtext}</p>}
      </Card>
    );
  }

  return (
    <Card className={`p-6 relative overflow-hidden ${className}`}>
      <h3 className="text-xs font-semibold text-reserve-gray tracking-wider uppercase mb-2">{title}</h3>
      <div className="flex items-baseline mb-1">
        <span className="text-4xl md:text-5xl font-serif text-reserve-dark">{value}</span>
        {unit && <span className="ml-1 text-reserve-gray">{unit}</span>}
      </div>
      {subtext && (
        <p className="text-sm font-medium text-reserve-green mt-2 flex items-center">
          {subtext}
        </p>
      )}
      {icon && (
        <div className="absolute right-[-20px] bottom-[-20px] opacity-10">
          {icon}
        </div>
      )}
    </Card>
  );
};

export default StatCard;
