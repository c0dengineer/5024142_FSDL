import React, { useState, useRef } from 'react';

const FileUpload = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState(null);
  const fileInputRef = useRef(null);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const processFile = (file) => {
    if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
        if (onFileSelect) onFileSelect(file);
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please select a JPG or PNG image under 10MB.');
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div
      className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${
        isDragging ? 'border-reserve-green bg-reserve-green/5' : 'border-gray-300 hover:border-reserve-green hover:bg-gray-50'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleChange}
        accept="image/png, image/jpeg"
        className="hidden"
      />
      
      {preview ? (
        <div className="flex flex-col items-center">
          <img src={preview} alt="Preview" className="h-32 object-contain rounded-lg mb-4 shadow-sm" />
          <p className="text-sm font-medium text-reserve-green hover:underline">Change photo</p>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 rounded-full bg-reserve-cream flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-reserve-green" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          </div>
          <h4 className="font-bold text-reserve-dark mb-1">Drag and drop food photos</h4>
          <p className="text-xs text-reserve-gray mb-4">PNG, JPG up to 10MB each</p>
          <span className="text-sm font-medium text-reserve-green underline decoration-reserve-green/30 underline-offset-4">Browse Files</span>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
