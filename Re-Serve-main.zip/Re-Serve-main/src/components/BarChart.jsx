import React from 'react';

const BarChart = ({ data = [30, 40, 35, 55, 45, 85, 40] }) => {
  const max = Math.max(...data);
  const days = ['MON', 'WED', 'FRI', 'SUN'];
  
  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex justify-between items-end mb-4">
        <h4 className="text-xs font-bold text-reserve-dark tracking-wider uppercase">Weekly Trend</h4>
        <span className="text-xs font-bold text-reserve-green">+12%</span>
      </div>
      
      <div className="flex-1 flex items-end justify-between space-x-2 pt-4 pb-2 h-32">
        {data.map((value, i) => {
          const height = `${(value / max) * 100}%`;
          const isHighest = value === max;
          
          return (
            <div key={i} className="w-full flex flex-col justify-end h-full group relative">
              <div 
                className={`w-full rounded-t-sm transition-all duration-500 ease-out ${isHighest ? 'bg-reserve-green' : 'bg-reserve-green/30 group-hover:bg-reserve-green/50'}`}
                style={{ height }}
              ></div>
            </div>
          );
        })}
      </div>
      
      <div className="flex justify-between text-[10px] font-bold text-reserve-gray mt-2 px-1">
        <span>MON</span>
        <span>WED</span>
        <span>FRI</span>
        <span>SUN</span>
      </div>
    </div>
  );
};

export default BarChart;
