import React from 'react';

const categories = [
  { id: 'all', label: 'ALL', icon: '⌘' },
  { id: 'bakery', label: 'BAKERY', icon: '🥐' },
  { id: 'veggies', label: 'VEGGIES', icon: '🥬' },
  { id: 'prepared', label: 'PREPARED', icon: '🍲' },
];

const CategoryFilter = ({ activeCategory, onSelect }) => {
  return (
    <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map((cat) => {
        const isActive = activeCategory === cat.id;
        return (
          <button
            key={cat.id}
            onClick={() => onSelect(cat.id)}
            className={`flex items-center whitespace-nowrap px-4 py-2 rounded-full text-xs font-bold tracking-wider transition-colors border ${
              isActive 
                ? 'bg-reserve-green text-white border-reserve-green shadow-sm' 
                : 'bg-white text-reserve-gray border-gray-200 hover:bg-gray-50'
            }`}
          >
            <span className="mr-2 text-sm">{cat.icon}</span>
            {cat.label}
          </button>
        );
      })}
    </div>
  );
};

export default CategoryFilter;
