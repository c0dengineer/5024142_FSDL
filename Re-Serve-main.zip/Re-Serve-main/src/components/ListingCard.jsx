import React from 'react';
import Card from './Card';
import Button from './Button';

const ListingCard = ({ listing, compact = false }) => {
  const { title, category, quantity, unit, timeRemaining, donor, distance, image, status } = listing;

  const statusColors = {
    Available: 'bg-green-100 text-green-800 border-green-200',
    Requested: 'bg-orange-100 text-orange-800 border-orange-200',
    'Picked Up': 'bg-gray-100 text-gray-800 border-gray-200',
  };

  if (compact) {
    return (
      <Card hoverEffect className="flex items-center p-4">
        <img src={image} alt={title} className="w-16 h-16 rounded-lg object-cover mr-4" />
        <div className="flex-1">
          <h4 className="font-medium text-reserve-dark text-sm">{title}</h4>
          <p className="text-xs text-reserve-red flex items-center mt-1">
            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Expiring in {timeRemaining}
          </p>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[10px] font-bold tracking-wider uppercase text-reserve-gray mb-1">Status</span>
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[status] || statusColors.Available}`}>
            {status}
          </span>
        </div>
      </Card>
    );
  }

  return (
    <Card hoverEffect className="flex p-4 items-center">
      <img src={image} alt={title} className="w-24 h-24 rounded-xl object-cover mr-5" />
      <div className="flex-1">
        <div className="flex justify-between items-start mb-1">
          <span className="text-[10px] font-bold tracking-wider uppercase text-reserve-gray">
            {category} • {quantity} {unit}
          </span>
          <span className="text-xs font-medium text-reserve-red flex items-center">
            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            {timeRemaining} left
          </span>
        </div>
        <h3 className="text-lg font-serif text-reserve-dark mb-1">{title}</h3>
        <p className="text-sm text-reserve-gray flex items-center">
          <svg className="w-4 h-4 mr-1 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
          {donor}
        </p>
        <p className="text-xs text-reserve-dark font-medium mt-2 flex items-center">
          <svg className="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          {distance} mi
        </p>
      </div>
      <div className="ml-4">
        <Button variant="primary" size="sm">REQUEST</Button>
      </div>
    </Card>
  );
};

export default ListingCard;
