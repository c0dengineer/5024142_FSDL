import React from 'react';

const Card = ({ children, className = '', hoverEffect = false }) => {
  const hoverClass = hoverEffect ? 'transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg' : '';
  
  return (
    <div className={`bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden ${hoverClass} ${className}`}>
      {children}
    </div>
  );
};

export default Card;
