import React from 'react';

const Loader = ({ fullScreen = false }) => {
  const spinner = (
    <div className="h-10 w-10 animate-spin rounded-full border-4 border-reserve-green border-t-transparent"></div>
  );

  if (fullScreen) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-reserve-cream">
        {spinner}
      </div>
    );
  }

  return (
    <div className="flex w-full items-center justify-center py-8">
      {spinner}
    </div>
  );
};

export default Loader;
