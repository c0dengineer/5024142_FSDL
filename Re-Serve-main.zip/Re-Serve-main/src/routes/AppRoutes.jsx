import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import AuthGuard from './AuthGuard';
import GuestGuard from './GuestGuard';

// Lazy loaded pages
const LandingPage = lazy(() => import('../pages/LandingPage'));
const LoginPage = lazy(() => import('../pages/LoginPage'));
const SignupPage = lazy(() => import('../pages/SignupPage'));
const DashboardPage = lazy(() => import('../pages/DashboardPage'));
const FindFoodPage = lazy(() => import('../pages/FindFoodPage'));
const DonatePage = lazy(() => import('../pages/DonatePage'));
const ImpactPage = lazy(() => import('../pages/ImpactPage'));

// Placeholder components until pages are built
const FallbackLoader = () => (
  <div className="flex h-screen w-full items-center justify-center bg-reserve-cream">
    <div className="h-12 w-12 animate-spin rounded-full border-4 border-reserve-green border-t-transparent"></div>
  </div>
);

const AppRoutes = () => {
  return (
    <Suspense fallback={<FallbackLoader />}>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        
        {/* Guest Only Routes (Redirect to dashboard if logged in) */}
        <Route path="/login" element={
          <GuestGuard>
            <LoginPage />
          </GuestGuard>
        } />
        <Route path="/signup" element={
          <GuestGuard>
            <SignupPage />
          </GuestGuard>
        } />

        {/* Protected Routes */}
        <Route path="/dashboard" element={
          <AuthGuard>
            <DashboardPage />
          </AuthGuard>
        } />
        <Route path="/find-food" element={
          <AuthGuard>
            <FindFoodPage />
          </AuthGuard>
        } />
        <Route path="/donate" element={
          <AuthGuard>
            <DonatePage />
          </AuthGuard>
        } />
        <Route path="/impact" element={
          <AuthGuard>
            <ImpactPage />
          </AuthGuard>
        } />
      </Routes>
    </Suspense>
  );
};

export default AppRoutes;
