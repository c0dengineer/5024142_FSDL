import { collection, addDoc, getDocs, query, where, orderBy, doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';

// Collections
const USERS_COL = 'users';
const LISTINGS_COL = 'listings';
const DONATIONS_COL = 'donations';

export const createUserProfile = async (uid, data) => {
  try {
    await setDoc(doc(db, USERS_COL, uid), data, { merge: true });
    return { error: null };
  } catch (error) {
    return { error: error.message };
  }
};

export const getUserProfile = async (uid) => {
  try {
    const docRef = doc(db, USERS_COL, uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { data: docSnap.data(), error: null };
    }
    return { data: null, error: 'Profile not found' };
  } catch (error) {
    return { data: null, error: error.message };
  }
};

export const createListing = async (listingData) => {
  try {
    const docRef = await addDoc(collection(db, LISTINGS_COL), {
      ...listingData,
      createdAt: new Date().toISOString()
    });
    return { id: docRef.id, error: null };
  } catch (error) {
    return { id: null, error: error.message };
  }
};

export const getActiveListings = async () => {
  try {
    const q = query(collection(db, LISTINGS_COL), where('status', '==', 'available'));
    const querySnapshot = await getDocs(q);
    const listings = [];
    querySnapshot.forEach((doc) => {
      listings.push({ id: doc.id, ...doc.data() });
    });
    return { data: listings, error: null };
  } catch (error) {
    return { data: null, error: error.message };
  }
};
