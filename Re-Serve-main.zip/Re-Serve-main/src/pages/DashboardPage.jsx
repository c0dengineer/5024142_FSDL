import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Button from '../components/Button';
import StatCard from '../components/StatCard';
import ListingCard from '../components/ListingCard';
import Card from '../components/Card';
import BarChart from '../components/BarChart';
import Toast from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';

const DashboardPage = () => {
  const { user } = useAuth();
  const [showToast, setShowToast] = useState(true);
  
  // Dummy data
  const listings = [
    { id: 1, title: '10kg Pasta - Whole Grain', status: 'Available', timeRemaining: '2h', image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=200&h=200&fit=crop' },
    { id: 2, title: 'Box of Organic Veggies', status: 'Requested', location: 'Central Market Depot', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&h=200&fit=crop' },
    { id: 3, title: 'Artisan Bread Assortment', status: 'Picked Up', donor: 'NGO: Hope Kitchen', image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=200&h=200&fit=crop' }
  ];

  const firstName = user?.displayName ? user.displayName.split(' ')[0] : 'Arthur';

  return (
    <div className="min-h-screen flex flex-col bg-[#F9FAFB]">
      <Navbar />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <p className="text-xs font-bold tracking-[0.2em] text-reserve-orange mb-2 uppercase">The Curated Harvest</p>
            <h1 className="text-4xl md:text-5xl font-serif text-reserve-dark mb-3">Welcome back, {firstName}.</h1>
            <p className="text-reserve-gray text-lg">Your contributions today are nourishing 124 families in your local community.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 shrink-0">
            <Button variant="secondary" icon={() => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}>
              FULL REPORT
            </Button>
            <Link to="/donate">
              <Button variant="primary" icon={() => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>}>
                ADD NEW DONATION
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <StatCard 
            title="Total Food Donated" 
            value="2,840" 
            unit="kg"
            className="md:col-span-1 shadow-sm border-0"
            icon={<svg className="w-32 h-32 text-reserve-green" fill="currentColor" viewBox="0 0 24 24"><path d="M17 8C8 10 5 16 5 22h2c0-5 3-9 9-11V8z" /><path d="M17 3v5c0 0 4-1 6-5-2 0-6 0-6 0z" /></svg>}
          />
          <StatCard 
            title="Active Listings" 
            value="12" 
            subtext={<><svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>4 New Today</>}
            className="shadow-sm border-0"
          />
          <StatCard 
            title="Lives Impacted" 
            value="412" 
            subtext={<><svg className="w-3 h-3 mr-1 text-reserve-orange" fill="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg><span className="text-reserve-orange">Record Month</span></>}
            className="shadow-sm border-0"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Active Listings Column */}
          <div className="lg:col-span-2">
            <div className="flex justify-between items-end mb-6">
              <h2 className="text-2xl font-serif text-reserve-dark">Active Listings</h2>
              <button className="text-sm font-bold text-reserve-green hover:underline">View All</button>
            </div>
            <Card className="p-2 space-y-2 border-0 shadow-sm bg-white">
              {listings.map(listing => (
                <ListingCard key={listing.id} listing={listing} compact />
              ))}
            </Card>
          </div>

          {/* Analytics Column */}
          <div className="flex flex-col gap-6">
            <div>
              <h2 className="text-2xl font-serif text-reserve-dark mb-6">Impact Analytics</h2>
              <Card className="p-6 border-0 shadow-sm h-64">
                <BarChart />
              </Card>
            </div>
            
            <Card className="bg-reserve-green text-white p-6 border-0 shadow-md relative overflow-hidden flex-1 flex flex-col justify-center">
              <div className="absolute -right-10 -top-10 opacity-10">
                <svg className="w-40 h-40" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
              </div>
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-2">Partner with a local NGO?</h3>
                <p className="text-sm opacity-90 mb-6 leading-relaxed">Boost your impact by setting up recurring daily pickups with our trusted network.</p>
                <Button variant="secondary" className="bg-white/20 text-white hover:bg-white/30 border-0" size="sm">
                  GET STARTED
                </Button>
              </div>
            </Card>
          </div>
        </div>

      </main>

      {showToast && (
        <Toast 
          message="Pasta donation claimed by Hope Kitchen 2m ago." 
          onClose={() => setShowToast(false)} 
        />
      )}

      <Footer />
    </div>
  );
};

export default DashboardPage;
