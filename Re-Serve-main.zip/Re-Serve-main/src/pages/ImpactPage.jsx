import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import StatCard from '../components/StatCard';
import Card from '../components/Card';

const ImpactPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-[#F9FAFB]">
      <Navbar />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="text-center mb-16">
          <p className="text-xs font-bold tracking-[0.2em] text-reserve-green mb-3 uppercase">Our Global Footprint</p>
          <h1 className="text-4xl md:text-6xl font-serif text-reserve-dark mb-6">The scale of our impact.</h1>
          <p className="text-reserve-gray text-lg max-w-2xl mx-auto">
            See how surplus food is transforming communities across the network. Real numbers, real lives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <StatCard title="Total Meals Served" value="2.4M" className="shadow-sm border-0" highlight />
          <StatCard title="Carbon Offset" value="840" unit="tons" className="shadow-sm border-0" />
          <StatCard title="Active NGOs" value="450+" className="shadow-sm border-0" />
          <StatCard title="Cities" value="12" className="shadow-sm border-0" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
           <Card className="bg-reserve-dark text-white p-10 h-80 flex flex-col justify-end relative overflow-hidden group border-0">
             <img src="https://images.unsplash.com/photo-1593113565637-681640f1a4e1?w=800&h=600&fit=crop" className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-opacity duration-500" alt="Community" />
             <div className="relative z-10">
               <h3 className="text-3xl font-serif mb-2">Community Kitchen Project</h3>
               <p className="text-reserve-cream/80 max-w-md">How fresh produce donations helped sustain 500 families in the downtown district this winter.</p>
             </div>
           </Card>
           
           <Card className="bg-reserve-green p-10 h-80 flex flex-col justify-end relative overflow-hidden group border-0">
             <div className="absolute top-0 right-0 p-8 opacity-10">
               <svg className="w-48 h-48" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
             </div>
             <div className="relative z-10 text-white">
               <h3 className="text-3xl font-serif mb-2">Zero Food Waste Initiative</h3>
               <p className="text-white/80 max-w-md">Our commitment to ensuring that not a single perfectly good meal ends up in a landfill.</p>
             </div>
           </Card>
        </div>

      </main>
      
      <Footer />
    </div>
  );
};

export default ImpactPage;
