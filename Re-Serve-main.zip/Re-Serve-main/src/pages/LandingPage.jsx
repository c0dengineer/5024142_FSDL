import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Button from '../components/Button';
import StatCard from '../components/StatCard';
import Card from '../components/Card';

const LandingPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative px-4 sm:px-6 lg:px-8 py-16 md:py-24 max-w-7xl mx-auto flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 pr-0 md:pr-12 mb-12 md:mb-0">
            <p className="text-xs font-bold tracking-[0.2em] text-reserve-orange mb-6 uppercase">Redefining Food Stewardship</p>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif text-reserve-dark leading-[1.1] mb-6">
              Harvesting surplus,<br />
              <span className="text-reserve-green italic">Feeding communities.</span>
            </h1>
            <p className="text-lg text-reserve-gray max-w-lg mb-10 leading-relaxed">
              ReServe bridges the gap between high-end culinary surplus and local NGOs. Join the movement that treats every meal as a precious resource.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/signup">
                <Button variant="primary" size="lg" fullWidth>JOIN AS A DONOR</Button>
              </Link>
              <Link to="/signup">
                <Button variant="secondary" size="lg" fullWidth className="bg-[#E5E7EB]/50 hover:bg-[#E5E7EB]">REGISTER AS NGO</Button>
              </Link>
            </div>
          </div>
          
          <div className="w-full md:w-1/2 relative">
            <div className="relative rounded-[2rem] overflow-hidden shadow-2xl">
              {/* Placeholder for hero image */}
              <div className="aspect-[4/3] bg-reserve-dark flex items-center justify-center">
                <div className="text-reserve-cream text-center p-8">
                   [Kitchen Hero Image]<br/>
                   Run phase 7 to generate assets.
                </div>
              </div>
            </div>
            {/* Overlay Badge */}
            <div className="absolute -bottom-6 -left-6 bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-xl flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-reserve-orange/20 flex items-center justify-center text-reserve-orange">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
              </div>
              <div>
                <p className="text-sm font-bold text-reserve-dark">Community Impact</p>
                <p className="text-xs text-reserve-gray">42 meals shared in your area</p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="bg-white border-y border-gray-100 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-gray-100">
              <div className="py-4">
                <h3 className="text-5xl font-serif text-reserve-green mb-2">2.4M+</h3>
                <p className="text-xs font-bold tracking-wider text-reserve-gray uppercase">Meals Saved</p>
              </div>
              <div className="py-4">
                <h3 className="text-5xl font-serif text-reserve-green mb-2">1,200</h3>
                <p className="text-xs font-bold tracking-wider text-reserve-gray uppercase">Active Donors</p>
              </div>
              <div className="py-4">
                <h3 className="text-5xl font-serif text-reserve-green mb-2">450+</h3>
                <p className="text-xs font-bold tracking-wider text-reserve-gray uppercase">NGO Partners</p>
              </div>
            </div>
          </div>
        </section>

        {/* Lifecycle Section */}
        <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <p className="text-xs font-bold tracking-[0.2em] text-reserve-gray mb-4 uppercase">The Logistics of Care</p>
            <h2 className="text-4xl md:text-5xl font-serif text-reserve-dark leading-tight max-w-2xl mx-auto">
              A Seamless Lifecycle<br />from Surplus to Soul.
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 md:gap-24 relative">
            {/* For Donors */}
            <div>
              <div className="flex items-center gap-4 mb-10">
                <div className="h-[1px] flex-1 bg-reserve-green"></div>
                <h3 className="text-sm font-bold tracking-wider text-reserve-green uppercase">For Donors</h3>
                <div className="h-[1px] w-8 bg-reserve-green"></div>
              </div>
              <div className="space-y-12">
                {[
                  { title: "Post Your Harvest", desc: "Snap a photo of your high-quality surplus food and list it on our dashboard in seconds." },
                  { title: "Verified NGO Matching", desc: "Our editorial algorithm matches your donation with pre-vetted local community partners." },
                  { title: "Safe Seamless Handoff", desc: "Coordinate a swift, temperature-controlled pickup and receive instant impact analytics." }
                ].map((step, idx) => (
                  <div key={idx} className="flex gap-6">
                    <span className="text-5xl font-serif text-reserve-green/20 leading-none">0{idx + 1}</span>
                    <div>
                      <h4 className="text-xl font-bold text-reserve-dark mb-2">{step.title}</h4>
                      <p className="text-reserve-gray text-sm leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* For Receivers */}
            <div>
              <div className="flex items-center gap-4 mb-10">
                <div className="h-[1px] w-8 bg-reserve-orange"></div>
                <h3 className="text-sm font-bold tracking-wider text-reserve-orange uppercase">For Receivers</h3>
                <div className="h-[1px] flex-1 bg-reserve-orange"></div>
              </div>
              <div className="space-y-12">
                {[
                  { title: "Real-time Scouting", desc: "Access the curated inventory of high-quality produce and meals available in your zone." },
                  { title: "Curated Selection", desc: "Claim what matches your community's needs with a single tap on our mobile platform." },
                  { title: "Direct Impact Delivery", desc: "Integrate high-nutrient ingredients into your programs, tracking health metrics along the way." }
                ].map((step, idx) => (
                  <div key={idx} className="flex gap-6">
                    <span className="text-5xl font-serif text-reserve-orange/20 leading-none">0{idx + 1}</span>
                    <div>
                      <h4 className="text-xl font-bold text-reserve-dark mb-2">{step.title}</h4>
                      <p className="text-reserve-gray text-sm leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Testimonial & Retention Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 p-10 md:p-14 flex flex-col justify-center">
              <div className="text-reserve-orange mb-6">
                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" /></svg>
              </div>
              <h3 className="text-2xl md:text-3xl font-serif text-reserve-dark leading-snug mb-10">
                "ReServe hasn't just reduced our waste; it's transformed our relationship with the local community. The logistics are flawless."
              </h3>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full overflow-hidden">
                   <div className="w-full h-full bg-reserve-dark/10"></div>
                </div>
                <div>
                  <p className="font-bold text-reserve-dark text-sm">Julian Rossi</p>
                  <p className="text-xs text-reserve-gray font-bold tracking-wider uppercase">Executive Chef, Verdant Bistro</p>
                </div>
              </div>
            </Card>
            <StatCard 
              title="Donor Retention" 
              value="98%" 
              subtext="Our partners stay because we prioritize their dignity and operational efficiency."
              highlight
            />
          </div>
        </section>

        {/* Partners Footer Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 mb-10">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center border-t border-gray-200 pt-16">
            <div className="col-span-2 md:col-span-1 rounded-xl overflow-hidden shadow-sm h-24">
              <div className="w-full h-full bg-reserve-dark/5"></div>
            </div>
            <div className="text-center md:text-left"><p className="text-sm font-bold text-reserve-gray tracking-[0.2em]">LUSH FOODS</p></div>
            <div className="text-center md:text-left"><p className="text-sm font-bold text-reserve-gray tracking-[0.2em]">HARVEST CO.</p></div>
            <div className="text-center md:text-left"><p className="text-sm font-bold text-reserve-gray tracking-[0.2em]">GREEN PATH</p></div>
            <div className="text-center md:text-left"><p className="text-sm font-bold text-reserve-gray tracking-[0.2em]">THE KITCHEN</p></div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default LandingPage;
