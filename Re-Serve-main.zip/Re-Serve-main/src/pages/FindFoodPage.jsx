import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import MapComponent from '../components/MapComponent';
import ListingCard from '../components/ListingCard';
import CategoryFilter from '../components/CategoryFilter';

const FindFoodPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [expiringSoon, setExpiringSoon] = useState(true);

  const mockHarvests = [
    { id: 1, title: 'Morning Sourdough Batch', category: 'BAKERY', quantity: 15, unit: 'UNITS', timeRemaining: '45m', donor: 'Hearth & Flour Bakery', distance: 0.8, image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=400&fit=crop' },
    { id: 2, title: 'Assorted Organic Greens', category: 'VEGGIES', quantity: 20, unit: 'KG', timeRemaining: '4h', donor: 'Valley Fresh Market', distance: 2.4, image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=400&fit=crop' },
    { id: 3, title: 'Gourmet Box Lunches', category: 'PREPARED', quantity: 12, unit: 'BOXES', timeRemaining: '2h', donor: 'Blue Plate Catering', distance: 1.1, image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop' },
  ];

  const mapMarkers = [
    { position: { lat: 40.7150, lng: -74.0100 }, color: '#E67E22' }, // Orange - prepared
    { position: { lat: 40.7200, lng: -74.0050 }, color: '#2D6A2E' }, // Green - veggies
    { position: { lat: 40.7100, lng: -73.9950 }, color: '#2D6A2E' }, // Green
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-reserve-cream">
      <Navbar />
      
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        
        {/* Map Area (Left) */}
        <div className="w-full md:w-1/2 h-[40vh] md:h-full relative">
          <MapComponent markers={mapMarkers} />
          
          {/* Live Activity Overlay */}
          <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-4 py-3 rounded-2xl shadow-lg border border-white/50 flex items-center gap-3">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-reserve-orange border-2 border-white flex items-center justify-center text-white"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg></div>
              <div className="w-8 h-8 rounded-full bg-reserve-green border-2 border-white flex items-center justify-center text-white"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"/></svg></div>
            </div>
            <div>
              <p className="text-[10px] font-bold text-reserve-green uppercase tracking-wider mb-0.5">Live Activity</p>
              <p className="text-sm font-bold text-reserve-dark">14 New Harvests available</p>
            </div>
          </div>
        </div>

        {/* Listings Area (Right) */}
        <div className="w-full md:w-1/2 h-full flex flex-col bg-white overflow-hidden shadow-[-10px_0_30px_-15px_rgba(0,0,0,0.1)] z-10">
          
          <div className="p-6 md:p-8 border-b border-gray-100 flex-shrink-0">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-3xl font-serif text-reserve-dark mb-1">Available Harvests</h2>
                <p className="text-sm text-reserve-gray">Curated food redistribution for your NGO network.</p>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-reserve-orange tracking-wider uppercase">Expiring Soon</span>
                <button 
                  onClick={() => setExpiringSoon(!expiringSoon)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${expiringSoon ? 'bg-reserve-orange' : 'bg-gray-200'}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${expiringSoon ? 'translate-x-7' : 'translate-x-1'}`}></div>
                </button>
              </div>
            </div>

            <CategoryFilter activeCategory={activeCategory} onSelect={setActiveCategory} />
          </div>

          <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-4 bg-gray-50/50">
            {mockHarvests.map(harvest => (
              <ListingCard key={harvest.id} listing={harvest} />
            ))}
          </div>

          {/* Floating New Contribution Toast inside panel */}
          <div className="absolute bottom-6 left-1/2 md:left-3/4 -translate-x-1/2 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-4 border border-gray-100 z-20 w-[90%] max-w-sm">
             <div className="w-10 h-10 rounded-full bg-reserve-orange/10 flex items-center justify-center text-reserve-orange">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
             </div>
             <div>
               <p className="text-[10px] font-bold text-reserve-gray uppercase tracking-wider mb-0.5">New Contribution</p>
               <p className="text-sm font-bold text-reserve-dark">Food Angel donated 50kg Veggies</p>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default FindFoodPage;
