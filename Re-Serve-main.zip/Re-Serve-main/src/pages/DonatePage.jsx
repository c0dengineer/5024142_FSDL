import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Card from '../components/Card';
import FileUpload from '../components/FileUpload';
import Button from '../components/Button';

const DonatePage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-reserve-cream">
      <Navbar />
      
      <main className="flex-grow max-w-4xl mx-auto px-4 py-12 md:py-20 w-full relative">
        
        {/* Header */}
        <div className="mb-10 text-center md:text-left relative">
          <p className="text-xs font-bold tracking-[0.2em] text-reserve-orange mb-3 uppercase">Donor Flow</p>
          <h1 className="text-4xl md:text-5xl font-serif text-reserve-dark mb-4">Share Your Harvest</h1>
          <p className="text-reserve-gray text-lg max-w-2xl leading-relaxed">
            Turn surplus into sustenance. Every donation helps bridge the gap in our community's nutritional ecosystem.
          </p>
          
          {/* Floating Tooltip/Quote */}
          <div className="hidden lg:block absolute right-0 top-0 bg-reserve-green/10 border border-reserve-green/20 p-5 rounded-2xl max-w-xs rotate-2 shadow-sm">
             <div className="flex items-center gap-2 mb-2">
               <div className="w-6 h-6 rounded-full bg-reserve-orange flex items-center justify-center text-white"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
               <span className="font-bold text-reserve-dark text-sm">Harvest Tip</span>
             </div>
             <p className="text-sm text-reserve-green italic">"Small acts, when multiplied by millions, can transform the world."</p>
          </div>
        </div>

        {/* Form Container */}
        <Card className="p-6 md:p-12 mb-12 shadow-lg border-0 bg-white">
          <form className="space-y-12">
            
            {/* Section 1 */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-6 rounded-full bg-reserve-green text-white flex items-center justify-center text-xs font-bold">1</span>
                <h3 className="text-xl font-bold text-reserve-dark">Item Essentials</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2">Food Item Name</label>
                  <input type="text" placeholder="e.g., Artisan Sourdough Bread" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all" />
                </div>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2">Quantity</label>
                    <input type="number" placeholder="0" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all" />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2 opacity-0">Unit</label>
                    <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all appearance-none cursor-pointer">
                      <option>kg (Kilograms)</option>
                      <option>lbs (Pounds)</option>
                      <option>Units</option>
                      <option>Boxes</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-3">Category Selection</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {['Bakery', 'Veggies', 'Prepared', 'Grains'].map(cat => (
                    <button type="button" key={cat} className="flex flex-col items-center justify-center p-4 rounded-xl border border-gray-200 bg-white hover:bg-reserve-green/5 hover:border-reserve-green transition-all">
                      <span className="text-2xl mb-2">{cat === 'Bakery' ? '🥐' : cat === 'Veggies' ? '🥬' : cat === 'Prepared' ? '🍲' : '🌾'}</span>
                      <span className="text-sm font-bold text-reserve-dark">{cat}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <hr className="border-gray-100" />

            {/* Section 2 */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-6 rounded-full bg-reserve-green text-white flex items-center justify-center text-xs font-bold">2</span>
                <h3 className="text-xl font-bold text-reserve-dark">Logistics & Safety</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div>
                  <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2">Fresh Until</label>
                  <input type="datetime-local" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all" />
                  <p className="text-[10px] text-reserve-gray mt-2">Please ensure item is safe for consumption until this time.</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2">Pickup Address</label>
                  <div className="flex gap-2">
                    <input type="text" placeholder="Street, City, Zip" className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all" />
                    <Button variant="primary" type="button" size="sm" className="px-4 whitespace-nowrap bg-reserve-green text-white rounded-xl flex items-center gap-1">
                       <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                       USE CURRENT
                    </Button>
                  </div>
                </div>
              </div>

              <div className="mb-8">
                <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-3">Visual Verification</label>
                <FileUpload />
              </div>

              <div>
                <label className="block text-xs font-bold text-reserve-gray tracking-wider uppercase mb-2">Special Instructions (Optional)</label>
                <textarea rows="3" placeholder="e.g., Please buzz apartment 4B, or leave in the designated cooler box at the gate." className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-reserve-dark focus:ring-2 focus:ring-reserve-green focus:border-transparent outline-none transition-all resize-none"></textarea>
              </div>
            </div>

            <div className="flex flex-col items-center pt-6">
              <Button variant="primary" size="lg" className="w-full md:w-auto md:px-16" icon={() => <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>}>
                Confirm Donation
              </Button>
              <p className="text-[10px] text-reserve-gray mt-4">By submitting, you agree to our Food Safety Guidelines</p>
            </div>
          </form>
        </Card>

        {/* Bottom Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border-0 shadow-sm flex flex-col justify-center">
             <div className="w-10 h-10 rounded-full bg-reserve-orange/10 flex items-center justify-center text-reserve-orange mb-4">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
             </div>
             <h4 className="font-bold text-reserve-dark mb-2">Verified Quality</h4>
             <p className="text-sm text-reserve-gray leading-relaxed">Our community trust score increases for every detailed donation with clear photos.</p>
          </Card>
          <Card className="md:col-span-2 relative overflow-hidden h-40 md:h-auto group">
            <img src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&h=400&fit=crop" alt="Impact" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-reserve-dark/90 via-reserve-dark/40 to-transparent flex flex-col justify-end p-6">
               <p className="text-[10px] font-bold text-reserve-cream/80 uppercase tracking-wider mb-1">Impact Story</p>
               <h3 className="text-2xl font-serif text-white">You're joining 1,200 neighbors in the harvest today.</h3>
            </div>
          </Card>
        </div>

      </main>
      <Footer />
    </div>
  );
};

export default DonatePage;
